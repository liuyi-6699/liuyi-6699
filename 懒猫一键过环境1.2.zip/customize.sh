ui_print "*********************************************"
ui_print "- 准备刷入..."
ui_print "- 酷安@懒猫不是猫"
ui_print "- [Zygisk Next-v1.2.7]"
ui_print "- [Shamiko-v1.2.3-395-release]"
ui_print "- [③Tricky-Store-v1.2.0-155-331f6fe-release]"
ui_print "- [WJWRootHideAuxiliary_1.6.1]"
ui_print "- [PlayIntegrityFix_v18.5]"
ui_print "- [LSPosed-v1.9.2-7249-Irena-release]"

ui_print "- lsposed可替换成自己的"
ui_print "- 这里不提供密钥，密钥需要自己寻找并替换"

ui_print "*********************************************"

CLEAN="$MODPATH"
for ZIPFILE in $CLEAN/*.zip; do
    install_module
done


ui_print "- 修复刷不进去"
ui_print "- 更新模块隐藏效果更强"
ui_print "- 可否赏脸去酷安关注一下？"


ui_print "---------------------------------"
  ui_print "- 酷安：$MODULE_CoolAPKID"
  ui_print "- 请选择是否跳转酷安主页@懒猫不是猫"
  ui_print "- 音量+ ：跳转"
  ui_print "- 音量- ：取消"
  ui_print "---------------------------------"

  choice=$(timeout 5 getevent -lc 1 2>/dev/null | grep "KEY_VOLUME" | awk '{print $3}' | tail -n 1)

  case $choice in
    "KEY_VOLUMEUP")
        ui_print "- 你选择跳转酷安主页，感谢支持"
        ui_print "- 正在跳转酷安主页..."
        am start -a android.intent.action.VIEW -d "http://www.coolapk.com/u/34247294$MODULE_CoolAPKID"
        ;;
    "KEY_VOLUMEDOWN")
        ui_print "- 你选择了不跳转，安装结束"
        ;;
    *)
        ui_print "- 未检测到有效输入，操作已取消，安装结束"
        ;;
  esac
  